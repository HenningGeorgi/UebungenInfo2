package Blatt10.data;

public class IllegalBankingException extends Exception {
    public IllegalBankingException(String message) {
        super(message);
    }
}
